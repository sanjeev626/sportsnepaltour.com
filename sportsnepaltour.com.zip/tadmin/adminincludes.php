<link rel="stylesheet" type="text/css" href="<?php echo SITEROOT; ?>tadmin/css/adminloginstyle.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOT; ?>tadmin/css/css.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOT; ?>tadmin/css/screen.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOT; ?>tadmin/css/adminnav.css" media="screen">
<!-- Animated Form Switching -->
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOT; ?>tadmin/css/animatedformcss.css">


<script type="text/javascript" src="js/scripts.js"></script>

<?php /*?><script type="text/javascript" src="<?php echo SITEROOT; ?>scripts/adminvalidation.js"></script>
<script type="text/javascript" src="<?php echo SITEROOT; ?>scripts/ajax.js"></script>
<link rel="stylesheet" href="<?php echo SITEROOT; ?>test/screen.css" type="text/css" media="screen" title="default" /><?php */?>

<!-- jQuery Validation -->
<?php /*?><link rel="stylesheet" type="text/css" href="<?php echo SITEROOT;?>jquery/jquery.validate.css" />
<script src="<?php echo SITEROOT;?>jquery/jquery.validate.js" type="text/javascript"></script>
<script src="<?php echo SITEROOT;?>jquery/jquery.validation.functions.js" type="text/javascript"></script><?php */?>
<!-- jQuery Validation Ends Here -->