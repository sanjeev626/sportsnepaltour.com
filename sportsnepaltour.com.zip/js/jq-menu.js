// JavaScript Document
$(document).ready(function() {
			$("li#ntours").hover(
function(){$(".sub").css('display','block')},
function(){$(".sub").css('display','none')}
									);
			
			$(".sub").hover(
function(){$(this).css('display','block')},
function(){$(this).css('display','none')}
									);

                       $("li#dtours").hover(
function(){$(".sub5").css('display','block')},
function(){$(".sub5").css('display','none')}
									);
			
			$(".sub5").hover(
function(){$(this).css('display','block')},
function(){$(this).css('display','none')}
									);
			
			
			$("li#trekking").hover(
function(){$(".sub1").css('display','block')},
function(){$(".sub1").css('display','none')}
									);
			
			$(".sub1").hover(
function(){$(this).css('display','block')},
function(){$(this).css('display','none')}
									);
									
			$("li#climbing").hover(
function(){$(".sub2").css('display','block')},
function(){$(".sub2").css('display','none')}
									);
			
			$(".sub2").hover(
function(){$(this).css('display','block')},
function(){$(this).css('display','none')}
									);
									
			$("li#btours").hover(
function(){$(".sub3").css('display','block')},
function(){$(".sub3").css('display','none')}
									);
			
			$(".sub3").hover(
function(){$(this).css('display','block')},
function(){$(this).css('display','none')}
									);
									
			$("li#ttours").hover(
function(){$(".sub4").css('display','block')},
function(){$(".sub4").css('display','none')}
									);
			
			$(".sub4").hover(
function(){$(this).css('display','block')},
function(){$(this).css('display','none')}
									);
									
		
	
}
						  );
						  
	