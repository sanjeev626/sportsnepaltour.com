<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>clueTip Plugin Demo</title>

  <link rel="stylesheet" href="tooltip/jquery.cluetip.css" type="text/css" />

  <script src="tooltip/jquery.min.js"></script>
  <!-- other scripts are below, just above the closing </body tag -->
</head>
<body>
  <br>

    This is a test. This is a test. This is a test. This is a test. This is a test. This is a test. This is a test. This is a test. <a class="jt" href="http://localhost/MyProjects/prj/sportstoursandtravel/tooltip.php?width=500&amp;pid=1" rel="http://localhost/MyProjects/prj/sportstoursandtravel/tooltip.php?width=500&amp;pid=1" title="jTip Style!">jTip Style clueTip</a>
  <script src="tooltip/jquery.cluetip.js"></script>
  <!-- <script src="jquery.cluetip.compat.js"></script> -->
  <script src="tooltip/demo.js"></script>

</body>
</html>