<div class="nav"> You are here > <a href="<?php echo SITEROOT;?>">Home</a> > <a href="<?php echo SITEROOT;?>news-and-events.html">News and Events</a> > <a href=""><?php echo $title;?></a> </div>
<!--nav-->
<h1><?php echo $title;?></h1>
<div class="de">&nbsp;</div>
<div class="pdes">
	<?php echo $contents;?>
</div>