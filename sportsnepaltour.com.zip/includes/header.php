<div class="hdt">
    <div class="act">
        <ul>
            <li id="au"><a href="<?php echo SITEROOT;?>about-us.html">About Us</a></li>
            <li id="cu"><a href="<?php echo SITEROOT;?>contact-us.html">Contact Us</a></li>
            <li id="ts"><a href="<?php echo SITEROOT;?>testimonials.html">Testimonials</a></li>
        </ul>            	
    </div><!--act-->
    <div class="et">
        Email: <a href="mailto:info@sportsnepaltour.com">info@sportsnepaltour.com</a><br />
        Tel: 00977-9849411819
    </div><!--et-->
    <div class="social">
        <a href="https://www.facebook.com/pages/Sports-Tours-and-Travel/391212987618615" target="_blank"><img src="<?php echo SITEROOT;?>im/fb-ico.gif" /></a>
        <a href="https://twitter.com/sportsnepaltour" target="_blank"><img src="<?php echo SITEROOT;?>im/twit-ico.gif" /></a>
        <a href="mailto:info@sportsnepaltour.com"><img src="<?php echo SITEROOT;?>im/mail-ico.gif" /></a><br />
        <a href="callto:sportstravel2001"><img src="<?php echo SITEROOT;?>im/skype-ico.gif" /></a>
        
    </div><!--social-->
</div><!--hdt-->
<?php include('includes/topmenu.php');?> 