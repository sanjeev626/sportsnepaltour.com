<div class="bmnu">
  <ul>
    <li><a href="<?php echo SITEROOT;?>">Home</a></li>
    <li><a href="<?php echo SITEROOT;?>about-us.html">About Us </a></li>
    <li><a href="<?php echo SITEROOT;?>contact-us.html">Contact Us</a></li>
    <li><a href="<?php echo SITEROOT;?>link-exchange.html">Link Exchange</a></li>
    <li><a href=""></a></li>
  </ul>
</div>
<!--bmnu-->
<div class="copy"> © 2010-2012 Sports Nepal Tours and Travel Pvt. Ltd. All Right Reserved.<br />
  No part of this publication may be reproduced, stored or transmitted in any form, without a written permission. </div>
<!--copy-->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36023953-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>




