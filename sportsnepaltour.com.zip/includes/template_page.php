<div class="nav"> You are here > <a href="<?php echo SITEROOT;?>">Home</a> > <a href=""><?php echo $title;?></a> </div>
<!--nav-->
<h1><?php echo $title;?></h1>

<div class="pdes">
	<?php echo $contents;?>
</div>