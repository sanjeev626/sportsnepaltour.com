<?php
	echo 'Id is equal to '.$_GET['id'];
?>